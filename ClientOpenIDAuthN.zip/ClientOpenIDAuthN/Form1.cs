﻿using Microsoft.Identity.Client;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;

namespace ClientOpenIDAuthN
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        readonly string INSTANCE = "https://login.microsoftonline.com";
        readonly string CERT_PASSWORD = "<certificate_password>";
        readonly string TENANT_ID = "6b95829c-73ae-43c9-b768-532ca4532cd3";
        readonly string CLIENT_ID = "045077e9-08c4-4d6e-914d-d5f1a9a8cd27";
        readonly string[] SCOPES = { "api://139c5b5e-ed8e-4bde-8da7-1e269808e6ac/.default" };


        private void btnGetToken_Click(object sender, EventArgs e)
        {
            string authority = $"{INSTANCE}/{TENANT_ID}";

            //By CERT
            X509Certificate2 cer = new X509Certificate2(@"<new_folder>\<certificate_name>", CERT_PASSWORD, X509KeyStorageFlags.EphemeralKeySet);
            var confidentialApplication = ConfidentialClientApplicationBuilder.Create(CLIENT_ID)
                .WithCertificate(cer)
                .WithAuthority(new Uri(authority))
                .Build();

            var token = confidentialApplication.AcquireTokenForClient(SCOPES)
                .ExecuteAsync()
                .GetAwaiter()
                .GetResult();

            txtToken.Text = token.AccessToken;

            //Request
            var url = "https://apiqa.pacificsource.com/FXIClaims.Api/FXI/Echo";

            HttpClient client = new HttpClient();
            client.Timeout = new TimeSpan(24, 0, 0);
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
            var response = client.SendAsync(request).GetAwaiter().GetResult();

            if (response.IsSuccessStatusCode)
            {
                var responseString = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                txtResult.Text = responseString;
            }
            else if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                txtResult.Text = "We are Unauthorized";
            }

        }


    }

}
